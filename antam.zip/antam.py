import time
import threading
import datetime
import requests
import json
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException, ElementNotInteractableException
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager


# ================================================================
# 🧩 KONFIGURASI
URL = "https://www.antributikemas.com/"  # URL target form
SITE_KEY = "6Le-wvkSAAAAAPBMRTvw0Q4Muexq9bi0DJwx_kl-"   # Sitekey target (contoh)
CAPSOLVER_API_KEY = "CAP-E89E53303A034396FF3E4F58B796D08553F3ED97E4666B3996AEFB6BF6CE3943"  # wajib diisi!
HEADLESS = False  # True = tanpa tampilan browser
JSON_FILE = "data.json"  # file berisi daftar data
# ================================================================


def baca_data_json(file_path):
    """Baca data dari file JSON"""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("Format JSON tidak valid, harus berupa list objek.")
        return data
    except Exception as e:
        print(f"❌ Gagal membaca file JSON: {e}")
        return []


def setup_driver(headless=False):
    options = Options()
    if headless:
        options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--start-maximized")
    return webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=options)


def find_input(driver, hints):
    """Cari elemen input berdasarkan hint teks"""
    for hint in hints:
        try:
            return driver.find_element(By.ID, hint)
        except NoSuchElementException:
            pass
        try:
            return driver.find_element(By.NAME, hint)
        except NoSuchElementException:
            pass
        try:
            return driver.find_element(By.XPATH, f"//input[contains(@placeholder, '{hint}')]")
        except NoSuchElementException:
            pass
        try:
            return driver.find_element(By.XPATH, f"//label[contains(., '{hint}')]/following::input[1]")
        except NoSuchElementException:
            pass
    return None


def fill_input_safe(driver, el, value):
    """Isi input dengan aman"""
    try:
        el.clear()
        el.send_keys(value)
    except ElementNotInteractableException:
        driver.execute_script("arguments[0].value = arguments[1];", el, value)


def wait_until_target_time(target_time_str):
    """Tunggu sampai jam target (format HH:MM WIB)."""
    now = datetime.datetime.utcnow() + datetime.timedelta(hours=7)
    target_today = datetime.datetime.combine(now.date(), datetime.datetime.strptime(target_time_str, "%H:%M").time())
    if now > target_today:
        print(f"⚠️ Waktu {target_time_str} WIB sudah lewat, lanjut kirim...")
        return
    while True:
        now = datetime.datetime.utcnow() + datetime.timedelta(hours=7)
        if now >= target_today:
            break
        time.sleep(0.2)


def inject_recaptcha_token(driver, token):
    """Masukkan token reCAPTCHA ke halaman"""
    js = """
    (function(token){
        var el = document.getElementById('g-recaptcha-response');
        if(!el){
            el = document.createElement('textarea');
            el.id = 'g-recaptcha-response';
            el.name = 'g-recaptcha-response';
            el.style.display = 'none';
            document.body.appendChild(el);
        }
        el.value = token;
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('input', { bubbles: true }));
    })(arguments[0]);
    """
    driver.execute_script(js, token)
    print("✅ Token reCAPTCHA v3 disuntikkan.")


def get_captcha_token(api_key, site_key, site_url):
    """Ambil token dari CapSolver API"""
    payload = {
        "clientKey": api_key,
        "task": {
            "type": "ReCaptchaV3TaskProxyless",
            "websiteURL": site_url,
            "websiteKey": site_key
        }
    }
    try:
        create_task = requests.post("https://api.capsolver.com/createTask", json=payload).json()
        task_id = create_task.get("taskId")
        if not task_id:
            print("❌ Gagal membuat task CapSolver:", create_task)
            return None

        # Cek status hingga selesai
        for _ in range(40):
            time.sleep(2)
            result = requests.post("https://api.capsolver.com/getTaskResult", json={
                "clientKey": api_key,
                "taskId": task_id
            }).json()
            if result.get("status") == "ready":
                token = result["solution"]["gRecaptchaResponse"]
                print("✅ Token berhasil didapat dari CapSolver.")
                return token
        print("❌ CapSolver timeout.")
        return None
    except Exception as e:
        print("❌ Error CapSolver:", e)
        return None


def run_bot(thread_id, data, barrier, target_time):
    """Menjalankan satu instance bot"""
    driver = setup_driver(HEADLESS)
    wait = WebDriverWait(driver, 15)
    nama = data.get("nama_ktp")
    ktp = data.get("nomor_ktp")
    hp = data.get("nomor_hp")

    try:
        print(f"[Thread {thread_id}] Membuka halaman: {URL}")
        driver.get(URL)
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "form")))

        # Isi form
        nama_input = find_input(driver, ["nama_ktp", "Nama", "Nama KTP"])
        ktp_input = find_input(driver, ["nomor_ktp", "no_ktp", "Nomor KTP", "NIK"])
        hp_input = find_input(driver, ["nomor_hp", "no_hp", "Nomor HP", "Handphone"])

        if nama_input:
            fill_input_safe(driver, nama_input, nama)
        if ktp_input:
            fill_input_safe(driver, ktp_input, ktp)
        if hp_input:
            fill_input_safe(driver, hp_input, hp)
        print(f"[Thread {thread_id}] Data form terisi.")

        # Centang checkbox
        for cb in driver.find_elements(By.XPATH, "//input[@type='checkbox']"):
            try:
                if not cb.is_selected():
                    cb.click()
                time.sleep(0.1)
            except:
                pass
        print(f"[Thread {thread_id}] Semua checkbox dicentang.")

        # reCAPTCHA otomatis
        print(f"[Thread {thread_id}] Mengambil token otomatis dari CapSolver...")
        token = get_captcha_token(CAPSOLVER_API_KEY, SITE_KEY, URL)
        if not token:
            print(f"[Thread {thread_id}] ❌ Gagal mendapatkan token reCAPTCHA.")
            return
        inject_recaptcha_token(driver, token)

        print(f"[Thread {thread_id}] Menunggu waktu kirim {target_time} WIB...")
        barrier.wait()  # sinkronisasi antar thread
        wait_until_target_time(target_time)

        # Klik submit
        submitted = False
        try:
            btn = driver.find_element(By.XPATH, "//button[contains(., 'Daftar') or contains(., 'Submit') or contains(., 'Kirim')]")
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
            btn.click()
            submitted = True
        except Exception:
            try:
                form = driver.find_element(By.XPATH, "//form")
                driver.execute_script("arguments[0].submit();", form)
                submitted = True
            except Exception as e:
                print(f"[Thread {thread_id}] ❌ Gagal submit otomatis: {e}")

        if submitted:
            print(f"✅ Berhasil! Nama: {nama} | No KTP: {ktp} | No HP: {hp}")
            time.sleep(5)
        else:
            print(f"❌ Gagal mengirim form untuk {nama}")

    finally:
        driver.quit()
        print(f"[Thread {thread_id}] Browser ditutup.")


# ================================================================
if __name__ == "__main__":
    data_list = baca_data_json(JSON_FILE)
    if not data_list:
        print("❌ Tidak ada data di file JSON.")
        exit()

    n = int(input("Berapa thread yang ingin dijalankan? "))
    target_time = input("Masukkan waktu pengiriman (format HH:MM WIB, contoh 07:30): ").strip()

    if n > len(data_list):
        print("⚠️ Jumlah thread melebihi data yang tersedia di file JSON.")
        exit()

    if not CAPSOLVER_API_KEY or CAPSOLVER_API_KEY == "YOUR_CAPSOLVER_API_KEY":
        print("❌ Harap isi CAPSOLVER_API_KEY terlebih dahulu!")
        exit()

    barrier = threading.Barrier(n)
    threads = []

    for i in range(n):
        t = threading.Thread(target=run_bot, args=(i + 1, data_list[i], barrier, target_time))
        threads.append(t)
        t.start()
        time.sleep(1)

    for t in threads:
        t.join()

    print("✅ Semua thread selesai dijalankan.")